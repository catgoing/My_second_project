package com.savanna.model.vo;

public interface SuperVO {
}
